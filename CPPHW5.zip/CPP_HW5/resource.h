﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++에서 생성한 포함 파일입니다.
// CPPHW5.rc에서 사용되고 있습니다.
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_CPPHW5TYPE                  130
#define ID_ACTION_DRAW                  32771
#define ID_ACTION_                      32772
#define ID_ACTION_SELECT                32773
#define ID_ACTION_GROUP                 32774
#define ID_ACTION_ALIGN                 32775
#define ID_ALIGN_BRINGFRONT             32776
#define ID_ALIGN_BRINGBACK              32777
#define ID_DRAW_RECTANGLE               32778
#define ID_DRAW_CIRCLE                  32779
#define ID_DRAW_CURVE                   32780
#define ID_DRAW_STAR                    32781
#define ID_ACTION_UNGROUP               32784
#define ID_ACTION_UNGROUP32791          32791

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        312
#define _APS_NEXT_COMMAND_VALUE         32792
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
